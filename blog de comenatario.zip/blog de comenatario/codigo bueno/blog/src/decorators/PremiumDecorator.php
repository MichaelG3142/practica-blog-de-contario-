<?php
// src/decorators/PremiumDecorator.php (abstract)
abstract class PremiumDecorator implements Contenido {
    protected Contenido $contenido;
    public function __construct(Contenido $contenido) { $this->contenido = $contenido; }
    public function getId(): int { return $this->contenido->getId(); }
    public function getTitulo(): string { return $this->contenido->getTitulo(); }
    public function getContenido(): string { return $this->contenido->getContenido(); }
    public function getAutorEmail(): string { return $this->contenido->getAutorEmail(); }
    abstract public function render(): string;
}
?>