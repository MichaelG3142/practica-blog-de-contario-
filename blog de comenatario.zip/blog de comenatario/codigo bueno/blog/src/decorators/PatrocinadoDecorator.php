<?php
// src/decorators/PatrocinadoDecorator.php
class PatrocinadoDecorator extends PremiumDecorator {
    public function render(): string {
        return "<span style='background:red;color:white;padding:4px;'>📣 PATROCINADO</span> " . $this->contenido->render();
    }
}
?>