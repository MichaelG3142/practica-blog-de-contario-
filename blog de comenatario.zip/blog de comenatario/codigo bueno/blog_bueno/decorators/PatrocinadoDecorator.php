<?php
// decorators/PatrocinadoDecorator.php
// PATRÓN: DECORATOR - Decorador Concreto

require_once __DIR__ . '/PremiumDecorator.php';

class PatrocinadoDecorator extends PremiumDecorator {
    public function render(): string {
        return "
            <span style='background: #ff3366; color: white; padding: 5px 10px; border-radius: 5px; font-weight: bold;'>
                📣 PATROCINADO
            </span><br><br>
            " . $this->contenido->render();
    }
}
?>