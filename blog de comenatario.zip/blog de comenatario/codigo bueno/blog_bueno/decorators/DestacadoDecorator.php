<?php
// decorators/DestacadoDecorator.php
// PATRÓN: DECORATOR - Decorador Concreto

require_once __DIR__ . '/PremiumDecorator.php';

class DestacadoDecorator extends PremiumDecorator {
    public function render(): string {
        return "
            <span style='background: #ffd700; color: black; padding: 5px 10px; border-radius: 5px; font-weight: bold;'>
                ⭐ DESTACADO
            </span><br><br>
            " . $this->contenido->render();
    }
}
?>