<?php
// decorators/PremiumDecorator.php
// PATRÓN: DECORATOR - Clase Abstracta Base

abstract class PremiumDecorator implements Contenido {
    protected Contenido $contenido;

    public function __construct(Contenido $contenido) {
        $this->contenido = $contenido;
    }

    // Delegamos los métodos básicos al contenido original
    public function getId(): int {
        return $this->contenido->getId();
    }

    public function getTitulo(): string {
        return $this->contenido->getTitulo();
    }

    public function getContenido(): string {
        return $this->contenido->getContenido();
    }

    public function getAutorEmail(): string {
        return $this->contenido->getAutorEmail();
    }

    // Método abstracto que deben implementar los decoradores concretos
    abstract public function render(): string;
}
?>