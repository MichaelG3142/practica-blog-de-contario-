<?php
// public/index.php
// Archivo principal - Interfaz del Blog

require_once '../config/Database.php';
require_once '../models/Contenido.php';
require_once '../models/Article.php';
require_once '../models/VideoContent.php';
require_once '../models/GalleryContent.php';
require_once '../core/BlogManager.php';
require_once '../core/ContenidoFactory.php';
require_once '../decorators/PremiumDecorator.php';
require_once '../decorators/DestacadoDecorator.php';
require_once '../decorators/PatrocinadoDecorator.php';

$manager = BlogManager::getInstance();

// Procesar creación de nueva publicación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear_publicacion'])) {
    $manager->crearPublicacion(
        $_POST['tipo'],
        $_POST['titulo'],
        $_POST['contenido'],
        $_POST['url_video'] ?? null,
        $_POST['autor_email']
    );
    
    header("Location: index.php?success=1");
    exit;
}

$contenidos = $manager->obtenerContenidos();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeonCode - Blog Abierto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body { 
            background: #0a0a0a; 
            color: #e0e0e0; 
            font-family: 'Segoe UI', sans-serif;
        }
        .navbar { background: rgba(10,10,10,0.97); backdrop-filter: blur(10px); }
        .hero { 
            background: linear-gradient(135deg, #00b4ff, #001f3f); 
            padding: 100px 0; 
        }
        .card {
            background: #121212;
            border: 1px solid #00b4ff;
            transition: all 0.3s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 180, 255, 0.3);
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold fs-3" href="#">NeonCode</a>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">
            <i class="fas fa-plus"></i> Crear Publicación
        </button>
    </div>
</nav>

<section class="hero text-center text-white">
    <div class="container">
        <h1 class="display-3 fw-bold">NeonCode</h1>
        <p class="lead">Un espacio abierto donde cualquiera puede publicar sus ideas</p>
    </div>
</section>

<div class="container py-5">
    <h2 class="mb-4 text-center">Publicaciones Recientes</h2>

    <?php if (empty($contenidos)): ?>
        <div class="alert alert-info text-center">No hay publicaciones aún. ¡Sé el primero en publicar!</div>
    <?php else: ?>
        <?php foreach ($contenidos as $contenido): ?>
            <div class="card mb-4">
                <div class="card-body">
                    <?= $contenido->render() ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Modal para Crear Publicación -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-light">
            <div class="modal-header">
                <h5 class="modal-title">Crear Nueva Publicación</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="crear_publicacion" value="1">

                    <div class="mb-3">
                        <label>Tipo de Publicación</label>
                        <select name="tipo" class="form-select bg-secondary text-light" required>
                            <option value="article">Artículo</option>
                            <option value="video">Video</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Título</label>
                        <input type="text" name="titulo" class="form-control bg-secondary text-light" required>
                    </div>

                    <div class="mb-3">
                        <label>Contenido</label>
                        <textarea name="contenido" class="form-control bg-secondary text-light" rows="6" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label>URL del Video (solo para videos)</label>
                        <input type="text" name="url_video" class="form-control bg-secondary text-light" placeholder="https://youtube.com/embed/...">
                    </div>

                    <div class="mb-3">
                        <label>Tu Email</label>
                        <input type="email" name="autor_email" class="form-control bg-secondary text-light" required>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Publicar Ahora</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>