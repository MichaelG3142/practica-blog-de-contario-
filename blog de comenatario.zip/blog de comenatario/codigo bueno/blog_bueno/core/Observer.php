<?php
// core/Observer.php
// PATRÓN: OBSERVER

interface Observador {
    public function update($data): void;
}

// Sujeto (Subject)
interface Sujeto {
    public function attach(Observador $observador);
    public function detach(Observador $observador);
    public function notify();
}
?>