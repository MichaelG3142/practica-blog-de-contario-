<?php
// core/BlogManager.php
// PATRÓN: SINGLETON

class BlogManager {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $this->pdo = Database::getInstance();
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getPDO() {
        return $this->pdo;
    }

    // Obtener todos los contenidos (usa Factory + Decorator)
    public function obtenerContenidos() {
        $stmt = $this->pdo->query("SELECT * FROM contenidos ORDER BY fecha DESC");
        $result = [];

        while ($row = $stmt->fetch()) {
            $contenido = ContenidoFactory::crear($row['tipo'], $row); // ← FACTORY

            // Aplicar decoradores si corresponde
            if (!empty($row['es_destacado'])) {
                $contenido = new DestacadoDecorator($contenido); // ← DECORATOR
            }
            if (!empty($row['es_patrocinado'])) {
                $contenido = new PatrocinadoDecorator($contenido); // ← DECORATOR
            }

            $result[] = $contenido;
        }
        return $result;
    }

    public function crearPublicacion($tipo, $titulo, $contenido, $url_video, $autor_email) {
        $stmt = $this->pdo->prepare("
            INSERT INTO contenidos (tipo, titulo, contenido, url_video, autor_email, fecha)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        return $stmt->execute([$tipo, $titulo, $contenido, $url_video, $autor_email]);
    }
}
?>