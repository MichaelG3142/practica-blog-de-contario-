<?php
// core/FiltroBusqueda.php
// PATRÓN: STRATEGY

interface BusquedaStrategy {
    public function filtrar(array $contenidos, string $query): array;
}

// Estrategia 1: Buscar por Fecha
class FechaStrategy implements BusquedaStrategy {
    public function filtrar(array $contenidos, string $query): array {
        return array_filter($contenidos, function($c) use ($query) {
            return str_contains($c['fecha'] ?? '', $query);
        });
    }
}

// Estrategia 2: Buscar por Categoría o Tags
class TagStrategy implements BusquedaStrategy {
    public function filtrar(array $contenidos, string $query): array {
        return array_filter($contenidos, function($c) use ($query) {
            $texto = strtolower(($c['contenido'] ?? '') . ' ' . ($c['titulo'] ?? ''));
            return str_contains($texto, strtolower($query));
        });
    }
}

// Contexto del Strategy
class FiltroBusqueda {
    private BusquedaStrategy $strategy;

    public function setStrategy(BusquedaStrategy $strategy) {
        $this->strategy = $strategy;
    }

    public function filtrar(array $contenidos, string $query): array {
        return $this->strategy->filtrar($contenidos, $query);
    }
}
?>