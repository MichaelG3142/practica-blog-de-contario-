<?php
// core/ContenidoFactory.php
// PATRÓN: FACTORY

class ContenidoFactory {
    public static function crear(string $tipo, array $data): Contenido {
        switch (strtolower($tipo)) {
            case 'video':
                return new VideoContent($data);
            case 'galeria':
                return new GalleryContent($data);
            default:
                return new Article($data);
        }
    }
}
?>