-- base.sql
CREATE DATABASE IF NOT EXISTS blog_bueno 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE blog_bueno;

DROP TABLE IF EXISTS comentarios;
DROP TABLE IF EXISTS contenidos;

CREATE TABLE contenidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('article', 'video', 'galeria') NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    contenido TEXT,
    url_video VARCHAR(500),
    autor_email VARCHAR(150),
    es_destacado TINYINT(1) DEFAULT 0,
    es_patrocinado TINYINT(1) DEFAULT 0,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contenido_id INT,
    nombre VARCHAR(100),
    texto TEXT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (contenido_id) REFERENCES contenidos(id) ON DELETE CASCADE
);

-- Datos de prueba
INSERT INTO contenidos (tipo, titulo, contenido, autor_email, es_destacado) VALUES
('article', 'Introducción a los Patrones de Diseño', 'Los patrones de diseño nos ayudan a escribir código más limpio y mantenible...', 'carlos@neoncode.com', 1),
('video', 'Explicación del Patrón Observer', 'https://youtube.com/embed/example123', 'ana@neoncode.com', 0),
('article', 'Decorator Pattern en PHP', 'El patrón Decorator permite agregar comportamiento dinámicamente...', 'miguel@neoncode.com', 0);