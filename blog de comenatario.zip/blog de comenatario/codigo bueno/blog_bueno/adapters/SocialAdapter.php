<?php
// adapters/SocialAdapter.php
// PATRÓN: ADAPTER

interface SocialAdapter {
    public function compartir(Contenido $contenido): string;
}

class TwitterAdapter implements SocialAdapter {
    public function compartir(Contenido $contenido): string {
        return "✅ Compartido en Twitter/X: " . $contenido->getTitulo();
    }
}

class FacebookAdapter implements SocialAdapter {
    public function compartir(Contenido $contenido): string {
        return "✅ Compartido en Facebook: " . $contenido->getTitulo();
    }
}

class InstagramAdapter implements SocialAdapter {
    public function compartir(Contenido $contenido): string {
        return "✅ Compartido en Instagram: " . $contenido->getTitulo();
    }
}
?>