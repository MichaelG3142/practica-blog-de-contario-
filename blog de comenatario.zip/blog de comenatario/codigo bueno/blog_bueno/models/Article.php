<?php
// models/Article.php

class Article implements Contenido {
    private $data;

    public function __construct(array $data) {
        $this->data = $data;
    }

    public function getId(): int {
        return (int)$this->data['id'];
    }

    public function getTitulo(): string {
        return $this->data['titulo'] ?? 'Sin título';
    }

    public function getContenido(): string {
        return $this->data['contenido'] ?? '';
    }

    public function getAutorEmail(): string {
        return $this->data['autor_email'] ?? '';
    }

    public function render(): string {
        return "
            <h2>" . htmlspecialchars($this->getTitulo()) . "</h2>
            <p>" . nl2br(htmlspecialchars($this->getContenido())) . "</p>
        ";
    }
}
?>