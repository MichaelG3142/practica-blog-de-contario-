<?php
// models/Contenido.php
// Interface base para todos los tipos de contenido

interface Contenido {
    public function getId(): int;
    public function getTitulo(): string;
    public function getContenido(): string;
    public function getAutorEmail(): string;
    public function render(): string;        // Cómo se muestra visualmente
}
?>