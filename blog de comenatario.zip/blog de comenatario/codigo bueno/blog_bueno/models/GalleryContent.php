<?php
// models/GalleryContent.php

class GalleryContent implements Contenido {
    private $data;

    public function __construct(array $data) {
        $this->data = $data;
    }

    public function getId(): int {
        return (int)$this->data['id'];
    }

    public function getTitulo(): string {
        return $this->data['titulo'] ?? 'Galería sin título';
    }

    public function getContenido(): string {
        return $this->data['contenido'] ?? '';
    }

    public function getAutorEmail(): string {
        return $this->data['autor_email'] ?? '';
    }

    public function render(): string {
        return "
            <h2>" . htmlspecialchars($this->getTitulo()) . "</h2>
            <div style='background:#1f1f1f; padding:15px; border-radius:8px;'>
                <strong>📸 Galería de Imágenes</strong><br>
                <p>" . nl2br(htmlspecialchars($this->getContenido())) . "</p>
            </div>
        ";
    }
}
?>