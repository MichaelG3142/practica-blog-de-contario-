<?php
// models/VideoContent.php

class VideoContent implements Contenido {
    private $data;

    public function __construct(array $data) {
        $this->data = $data;
    }

    public function getId(): int { return (int)$this->data['id']; }
    public function getTitulo(): string { return $this->data['titulo'] ?? 'Sin título'; }
    public function getContenido(): string { return $this->data['url_video'] ?? ''; }
    public function getAutorEmail(): string { return $this->data['autor_email'] ?? ''; }

    public function render(): string {
        $url = $this->getContenido();
        if (empty($url)) {
            return "<h2>" . htmlspecialchars($this->getTitulo()) . "</h2><p>Video no disponible</p>";
        }
        return "
            <h2>" . htmlspecialchars($this->getTitulo()) . "</h2>
            <div class='ratio ratio-16x9'>
                <iframe src='" . htmlspecialchars($url) . "' allowfullscreen></iframe>
            </div>
        ";
    }
}
?>