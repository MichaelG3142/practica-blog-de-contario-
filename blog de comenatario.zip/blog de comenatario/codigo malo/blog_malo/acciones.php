<?php
// acciones.php - TODO MAL HECHO


mysql_connect('localhost', 'root', '') or die("No se conectó a MySQL");
mysql_select_db('blog_malo') or die("Base de datos no existe");

if(isset($_POST['crear'])){
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    
    mysql_query("INSERT INTO articulos (titulo, contenido) VALUES ('$titulo', '$contenido')");
    header("Location: index.html");
    exit;
}

if(isset($_GET['ver'])){
    $id = (int)$_GET['ver'];
    $row = mysql_fetch_array(mysql_query("SELECT * FROM articulos WHERE id=$id"));
    
    echo "<h1>" . $row['titulo'] . "</h1>";
    echo "<p>" . $row['contenido'] . "</p>";
    echo "<hr><h3>Deja tu comentario</h3>";
    echo "<form method='post' action='acciones.php'>
            <input type='hidden' name='id_articulo' value='$id'>
            Nombre: <input type='text' name='nombre' required><br><br>
            Comentario:<br><textarea name='comentario' rows='5' cols='60'></textarea><br>
            <input type='submit' name='comentar' value='Comentar'>
          </form>";
}

if(isset($_POST['comentar'])){
    $id = (int)$_POST['id_articulo'];
    $nombre = $_POST['nombre'];
    $comentario = $_POST['comentario'];
    
    mysql_query("INSERT INTO comentarios (articulo_id, nombre, comentario) VALUES ($id, '$nombre', '$comentario')");

    mail("admin@blogmalo.com", "Nuevo comentario", "Artículo $id - $nombre dijo: $comentario");
    
    echo "Comentario enviado (supuestamente). <a href='index.html'>Volver</a>";
}

if(isset($_GET['nuevo'])){
    echo "
    <h2>Crear Artículo Nuevo</h2>
    <form method='post' action='acciones.php'>
        <input type='hidden' name='crear' value='1'>
        Título: <br><input type='text' name='titulo' size='50'><br><br>
        Contenido:<br><textarea name='contenido' rows='10' cols='60'></textarea><br><br>
        <input type='submit' value='Publicar'>
    </form>";
}
?>