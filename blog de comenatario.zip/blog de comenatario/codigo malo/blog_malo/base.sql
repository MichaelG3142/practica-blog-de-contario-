CREATE DATABASE IF NOT EXISTS blog_malo;
USE blog_malo;

CREATE TABLE articulos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255),
    contenido TEXT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    articulo_id INT,
    nombre VARCHAR(100),
    comentario TEXT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Datos de prueba
INSERT INTO articulos (titulo, contenido) VALUES 
('Mi primer artículo malo', 'Este es un contenido horrible pero funciona.'),
('Segundo post', 'Más basura escrita para llenar el blog.');